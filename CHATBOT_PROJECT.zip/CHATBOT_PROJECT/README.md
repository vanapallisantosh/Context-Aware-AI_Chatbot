# Context-Aware Customer Support Chatbot (Flask)

This project is a simple multi-turn customer support chatbot built with:
- Backend: Python + Flask
- Frontend: HTML/CSS/JavaScript chat UI
- NLP: keyword-based intent classification (modular so you can swap in ML later)

## Architecture (high level)

1. **Frontend (`/static/app.js`, `templates/index.html`)**
   - Renders chat bubbles.
   - Sends `{ "message": "..." }` to the backend with `POST /chat`.

2. **Flask backend (`app.py`)**
   - `GET /` renders the UI.
   - `POST /chat`:
     - Loads conversation state via `chatbot.context.get_conversation_state(session)`
     - Runs intent/entity parsing via `chatbot.nlp.parse_user_message_for_chat(...)`
     - Builds a coherent reply via `chatbot.responses.build_response(...)`
     - Logs the interaction (optional but implemented)

3. **NLP + response generation (modular)**
   - `chatbot/intents.py`: keyword intent detection + simple entity extraction (`order_id`, refund reason)
   - `chatbot/responses.py`: response templates + multi-turn logic using saved context
   - `chatbot/context.py`: in-memory conversation store keyed by a `conversation_id` stored in Flask session
   - `chatbot/logging_utils.py`: basic rotating log file (`logs/conversations.log`)

## Conversation Flow Design (multi-turn)

The chatbot maintains a per-user server-side state object with:
- `context.last_intent`: the last matched support topic (`order_status`, `refund_request`, `refund_policy`, etc.)
- `context.order_id`: last extracted order id (when present)
- `context.refund_reason`: last extracted refund reason (when present)

On each user message:
1. Intent/entity parsing runs (`parse_user_message_for_chat`)
2. If the message is ambiguous, follow-up heuristics use `last_intent`:
   - After `order_status`, short follow-ups like “update”, “where is it”, “delivery” keep `order_status`
   - After `refund_request`, “how long/timeline/policy” maps to `refund_policy`
3. Response generation uses the context:
   - `order_status`: if `order_id` is missing, ask for it; otherwise respond with a mock status
   - `refund_request`: if `order_id` missing, ask; if reason missing, ask; otherwise explain next steps
   - `refund_policy`: give general policy guidance
   - Unknown/general queries: ask a clarifying question and offer the support categories

## Features Implemented

- Multi-turn conversation context (server-side in-memory state)
- Basic keyword intent recognition
- Graceful unknown-query handling
- Predefined responses:
  - order status
  - refund request
  - refund policy
  - product/general queries
- Basic logging of conversations

## Example Dialogues

### Order status
User: Hi  
Bot: Hi! I can help with order status, refunds/returns, or general questions. What do you need?

User: Where is my order?  
Bot: I can check that. What’s your order number? If you don’t have it handy, tell me the email name used for the order.

User: ORD-123456  
Bot: Thanks—here’s the latest for order 123456: Shipped. Your order has left our warehouse. Would you like delivery tracking updates or help if something looks wrong?

### Refund request
User: I want a refund  
Bot: I can help with a refund. What’s your order number? Once I have it, I’ll guide you through the next steps.

User: 99887766  
Bot: Thanks. What’s the reason for the refund for order 99887766? For example: damaged item, wrong item, not as described, missing parts, or late delivery.

User: It arrived damaged  
Bot: Got it. Based on your request, here’s what we’ll do for order 99887766: It arrived damaged or defective. If your item is eligible, we’ll start the return/refund process...

### Refund policy follow-up
User: How long do refunds take?  
Bot: Refunds/returns are typically available... After approval, refunds usually process within 5–7 business days...

## Run Instructions

1. Install dependencies:
   - `pip install -r requirements.txt`
2. Start the server:
   - `python app.py`
3. Open in browser:
   - `http://127.0.0.1:5000`

## Notes / Next Improvements (optional)

- Replace the in-memory store with Redis/DB for persistence across restarts
- Add more training data for intent classification
- Connect order/refund logic to real APIs instead of mock statuses

## Training / Customization (optional but recommended)

The bot uses two data-driven pieces:

1. **FAQ answering** (`data/faq.json`)
   - For broad customer questions (shipping info, warranty, return policy, etc.), it selects the best matching FAQ answer.
   - Add more question/answer pairs to improve coverage.

2. **Intent classification** (ML)
   - Uses TF-IDF + Logistic Regression.
   - You can optionally extend training by creating `data/intent_training.json` in this format:
     - `[{ "text": "where is my order", "intent": "order_status" }, ...]`

