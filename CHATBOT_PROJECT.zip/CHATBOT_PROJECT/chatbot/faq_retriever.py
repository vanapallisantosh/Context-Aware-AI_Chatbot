import json
import os
from dataclasses import dataclass
from typing import List, Optional, Tuple

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class FaqHit:
    answer: str
    score: float
    question: str


def _load_faq(path: str) -> List[dict]:
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    # Basic validation
    out: List[dict] = []
    for item in data:
        if isinstance(item, dict) and "question" in item and "answer" in item:
            out.append({"question": str(item["question"]), "answer": str(item["answer"])})
    return out


def _build_index(faq_items: List[dict]) -> Tuple[TfidfVectorizer, object, List[dict]]:
    questions = [x["question"] for x in faq_items]
    vectorizer = TfidfVectorizer(lowercase=True, ngram_range=(1, 2), stop_words="english")
    matrix = vectorizer.fit_transform(questions)
    return vectorizer, matrix, faq_items


class FaqRetriever:
    def __init__(self, faq_path: Optional[str] = None, *, threshold: float = 0.22):
        if faq_path is None:
            faq_path = os.environ.get("CHATBOT_FAQ_PATH")
        self._faq_path = faq_path
        self._threshold = threshold
        self._vectorizer = None
        self._matrix = None
        self._items: List[dict] = []

        self._init()

    def _init(self) -> None:
        base_dir = os.path.dirname(os.path.dirname(__file__))
        default_path = os.path.join(base_dir, "data", "faq.json")
        faq_path = self._faq_path or default_path
        items = _load_faq(faq_path)
        if not items:
            self._items = []
            return
        self._vectorizer, self._matrix, self._items = _build_index(items)

    def answer(self, message: str) -> Optional[FaqHit]:
        if not self._items:
            return None
        query_vec = self._vectorizer.transform([message])
        sims = cosine_similarity(query_vec, self._matrix)[0]
        best_idx = int(sims.argmax())
        best_score = float(sims[best_idx])
        if best_score < self._threshold:
            return None
        item = self._items[best_idx]
        return FaqHit(
            answer=item["answer"],
            score=best_score,
            question=item["question"],
        )


_RETRIEVER: Optional[FaqRetriever] = None


def get_retriever() -> FaqRetriever:
    global _RETRIEVER
    if _RETRIEVER is None:
        _RETRIEVER = FaqRetriever()
    return _RETRIEVER


def answer_via_faq(message: str) -> Optional[FaqHit]:
    return get_retriever().answer(message)

