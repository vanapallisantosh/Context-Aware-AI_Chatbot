"""
Simple context-aware customer support chatbot.

This package is intentionally small and dependency-light (basic keyword NLP),
so you can extend it without needing ML infrastructure.
"""

