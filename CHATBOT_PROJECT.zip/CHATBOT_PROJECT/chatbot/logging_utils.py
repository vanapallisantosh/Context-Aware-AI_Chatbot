import logging
import os
from logging.handlers import RotatingFileHandler
from datetime import datetime


def get_logger() -> logging.Logger:
    logger = logging.getLogger("chatbot")
    logger.setLevel(logging.INFO)
    if logger.handlers:
        return logger

    log_path = os.environ.get("CHATBOT_LOG_PATH", "logs/conversations.log")
    log_dir = os.path.dirname(log_path)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)

    handler = RotatingFileHandler(log_path, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger


logger = get_logger()


def log_interaction(*, conversation_id: str, user_message: str, bot_reply: str, intent: str) -> None:
    """
    Keep logging simple and robust (no structured logging dependency).
    """
    logger.info(
        "conversation_id=%s intent=%s user=%r bot=%r",
        conversation_id,
        intent,
        user_message,
        bot_reply,
    )


def utc_now_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"

