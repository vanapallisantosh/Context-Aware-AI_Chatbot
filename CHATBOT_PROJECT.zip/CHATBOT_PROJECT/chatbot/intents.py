import re
from dataclasses import dataclass
from typing import Optional

from .ml_intent import predict_intent


INTENT_ORDER = [
    "order_status",
    "refund_request",
    "refund_policy",
    "product_info",
    "human_agent",
    "greeting",
    "general_query",
    "unknown",
]


DEFAULT_FALLBACK_INTENT = "unknown"


ORDER_ID_REGEX = re.compile(
    # Accept a bit more variety because real order formats differ.
    # Examples: "ORD-123456", "123456", "AB12 34567"
    r"(?i)\b(?:ord[-\s]?)?(\d{3,}|[A-Z]{2,4}\d{3,})\b"
)


def extract_order_id(text: str) -> Optional[str]:
    """
    Extract an order id from text using a simple regex.
    This is a heuristic; adapt it to your real order id format.
    """
    match = ORDER_ID_REGEX.search(text.strip())
    if not match:
        return None
    # Return only the captured group.
    return match.group(1)


def detect_refund_reason(text: str) -> Optional[str]:
    t = text.lower()
    signals = [
        ("damaged", "It arrived damaged or defective."),
        ("wrong item", "I received the wrong item."),
        ("not as described", "The item wasn’t as described."),
        ("late", "The delivery was late."),
        ("missing", "Some items were missing."),
        ("changed my mind", "I want to cancel because I changed my mind."),
        ("cancel", "I want to cancel the order."),
    ]
    for keyword, reason in signals:
        if keyword in t:
            return reason
    return None


EMAIL_REGEX = re.compile(
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
)


def extract_email(text: str) -> Optional[str]:
    match = EMAIL_REGEX.search(text)
    return match.group(0) if match else None


def keyword_intent(message: str) -> str:
    """
    Keyword-based intent matching fallback.
    Order matters: we check more specific intents first.
    """
    t = message.lower()

    # Greeting (word-boundary based to avoid "hi" matching inside other words like "shipping")
    if re.search(r"\b(hi|hello|hey)\b", t) or "good morning" in t or "good afternoon" in t:
        return "greeting"

    # Human agent
    if any(w in t for w in ["human", "agent", "representative", "customer service", "support person"]):
        return "human_agent"

    # Refund policy
    if any(
        w in t
        for w in [
            "refund policy",
            "return policy",
            "how long do refunds",
            "how long refunds",
            "return window",
            "returns",
        ]
    ):
        return "refund_policy"

    # Refund request
    # Avoid matching generic "return"/"returns" (often policy questions). Prefer request-like phrasing.
    refund_request_patterns = [
        r"\b(i want a refund|refund my order|requesting a refund)\b",
        r"\b(money back|chargeback)\b",
        r"\b(start return|start a return|send it back|return this|return this item|i need to return|i want to return)\b",
        r"\b(cancel my order|cancel order).*\b(refund|return)\b",
    ]
    if any(re.search(pat, t) for pat in refund_request_patterns) or ("refund" in t and "policy" not in t):
        return "refund_request"

    # Order status / tracking / delivery
    if any(
        w in t
        for w in [
            "order status",
            "track",
            "tracking",
            "tracking number",
            "delivery",
            "deliver",
            "shipping",
            "ship",
            "shipped",
            "out for delivery",
            "where is",
            "where's",
            "when will",
            "late",
            "not arrived",
            "overdue",
            "stuck",
        ]
    ):
        return "order_status"

    # Product info
    if any(
        w in t
        for w in [
            "price",
            "spec",
            "specs",
            "availability",
            "does it come",
            "does it have",
            "product details",
            "warranty",
            "compatible",
            "compatibility",
        ]
    ):
        return "product_info"

    # General query
    if len(t) > 0:
        return "general_query"

    return DEFAULT_FALLBACK_INTENT


@dataclass
class ParsedMessage:
    intent: str
    order_id: Optional[str] = None
    refund_reason: Optional[str] = None


def parse_user_message(message: str, last_intent: Optional[str]) -> ParsedMessage:
    """
    Parse intent and entities, using a little context-aware follow-up logic.
    """
    email = extract_email(message)
    order_id = extract_order_id(message)
    refund_reason = detect_refund_reason(message)

    # If the user is sending an email, avoid extracting an order id from the
    # digits that often appear in the email local-part (e.g., "123@gmail.com").
    if email and "@" in message:
        if not re.search(r"(?i)\bord[-\s]?\d+", message):
            order_id = None

    # Intent classification (ML first, then keyword fallback).
    # Use a higher threshold to avoid confidently picking the wrong flow.
    pred_intent = predict_intent(message, threshold=0.6).intent
    intent = pred_intent if pred_intent != "unknown" else keyword_intent(message)

    # If the user is asking about policy (e.g., "refund for late delivery")
    # rather than making an active refund request ("i want a refund"), steer to policy.
    t = message.lower()
    if intent == "refund_request" and "refund" in t and "late" in t:
        request_triggers = [
            "i want a refund",
            "refund my order",
            "requesting a refund",
            "start return",
            "start a return",
            "return this item",
            "money back",
            "chargeback",
            "cancel my order",
            "cancel order",
        ]
        if not any(x in t for x in request_triggers):
            intent = "refund_policy"

    # If the user previously asked about an order, keep using order_status unless
    # they clearly switched topics.
    t = message.lower()
    if last_intent == "order_status" and intent not in ["refund_request", "refund_policy", "human_agent"]:
        if any(w in t for w in ["update", "where", "when", "status", "tracking", "delivery"]):
            intent = "order_status"

    if last_intent in ["refund_request", "refund_policy"] and intent not in ["order_status", "human_agent"]:
        # Allow follow-up questions like "how long?" to map to refund policy.
        if any(w in t for w in ["how long", "timeline", "processing", "eligibility", "policy"]):
            intent = "refund_policy"
        elif refund_reason:
            intent = "refund_request"
        elif any(
            w in t
            for w in [
                "refund",
                "money back",
                "cancel",
                "start return",
                "start a return",
                "send it back",
                "return this",
                "return this item",
                "i need to return",
            ]
        ):
            intent = "refund_request"

    # When we're in an order flow and the user provides an email address,
    # treat it as the expected follow-up even if the keyword matcher would
    # otherwise classify it as general_query.
    if last_intent == "order_status" and email:
        intent = "order_status"

    # When we're in a refund flow and the user provides a reason like "wrong item",
    # ensure we stay on refund_request (avoid generic topic replies).
    if last_intent == "refund_request" and refund_reason:
        intent = "refund_request"

    # If the message looks like an order id alone, treat it as an order-status lookup.
    # This makes the bot respond to inputs like "123456" and "ORD-123456".
    if order_id:
        stripped = t.replace(order_id.lower(), "").strip()
        looks_like_only_id = stripped in ["", "-", "—", "–"]
        if looks_like_only_id and intent in ["general_query", "unknown"]:
            intent = "order_status"
        # If we have an order id and the user mentioned tracking/shipping keywords,
        # make sure intent is order_status (even if keyword_intent guessed general_query).
        if intent == "general_query" and any(
            w in t for w in ["order", "tracking", "track", "delivery", "shipping", "ship"]
        ):
            intent = "order_status"

    # If the user only says "shipping/ship" (no order id + no tracking keywords),
    # treat it as a general shipping question instead of an order lookup.
    if intent == "order_status" and not order_id:
        tracking_hints = [
            "track",
            "tracking",
            "where is",
            "where's",
            "where",
            "delivery",
            "deliver",
            "shipped",
            "out for delivery",
            "late",
            "arrive",
            "not arrived",
            "overdue",
            "stuck",
        ]
        if ("shipping" in t or "ship" in t) and not any(h in t for h in tracking_hints):
            intent = "general_query"

    return ParsedMessage(intent=intent, order_id=order_id, refund_reason=refund_reason)

