from typing import Optional, Tuple

from .context import append_history
from .intents import ParsedMessage, extract_email
from .faq_retriever import answer_via_faq


def build_response(state: dict, user_message: str, parsed: ParsedMessage) -> Tuple[str, dict]:
    """
    Generate a human-like support reply and update the conversation state.
    """
    # History is stored server-side in `state`.
    append_history(state, role="user", text=user_message)

    last_intent: Optional[str] = state["context"].get("last_intent")

    # Carry forward context if the new message doesn't include entities.
    if parsed.order_id:
        state["context"]["order_id"] = parsed.order_id
    if parsed.refund_reason:
        state["context"]["refund_reason"] = parsed.refund_reason

    order_id = state["context"].get("order_id")
    refund_reason = state["context"].get("refund_reason")

    intent = parsed.intent
    # If NLP couldn't classify, only reuse last intent when the message looks
    # like a follow-up (e.g., short "where is it?" after order status).
    if intent == "unknown" and last_intent in {"order_status", "refund_request", "refund_policy"}:
        t = user_message.lower()
        followups_by_intent = {
            "order_status": ["update", "where", "when", "status", "tracking", "delivery", "shipped", "arrive", "late"],
            "refund_request": ["reason", "refund", "return", "money back", "cancel", "send", "start"],
            "refund_policy": ["how long", "timeline", "processing", "eligibility", "policy", "when will", "refunds"],
        }
        followups = followups_by_intent.get(last_intent, [])
        if any(w in t for w in followups):
            intent = last_intent

    # Extra safety: if we are mid refund-request and we extracted a reason,
    # keep the refund flow (prevents generic topic replies).
    if last_intent == "refund_request" and refund_reason:
        intent = "refund_request"

    if intent == "greeting":
        reply = (
            "Hi! I can help with order status, refunds/returns, or general questions. "
            "What do you need help with?"
        )

    elif intent == "human_agent":
        # Keep it short and ask for the minimum info needed.
        if order_id:
            reply = (
                "Sure—I can connect you to a human support agent. "
                f"Thanks. Please describe the issue for order {order_id}."
            )
        else:
            reply = (
                "Sure—I can connect you to a human support agent. "
                "Please share your order number (if you have it) and what happened."
            )

    elif intent == "order_status":
        waiting_for_email: bool = bool(state["context"].get("waiting_for_order_email"))
        if not order_id:
            reply = (
                "I can help check that. What’s your order number? "
                "If you have it, include it exactly like it appears on your confirmation email."
            )
        elif waiting_for_email:
            email = extract_email(user_message)
            if not email:
                reply = (
                    f"Thanks—I have the order number {order_id}. "
                    "To look it up, please share the email address used at checkout."
                )
            else:
                # Demo behavior: we can't access your real order system here.
                # We respond deterministically and ask what they want next.
                state["context"]["waiting_for_order_email"] = False
                reply = (
                    f"Thanks! I found order {order_id} for {email}. "
                    "It’s currently being processed and should ship soon. "
                    "If you tell me whether you need 'tracking' or you’re 'worried it’s late', "
                    "I’ll guide you to the next step."
                )
        else:
            state["context"]["waiting_for_order_email"] = True
            reply = (
                f"Thanks. What’s the email address used for order {order_id}? "
                "Once you share it, I’ll help with the next steps (tracking/arrival)."
            )

    elif intent == "refund_policy":
        hit = answer_via_faq(user_message)
        if hit is not None:
            reply = hit.answer
        else:
            reply = (
                "Refunds/returns are typically available within our return window (most orders qualify "
                "within 30 days of purchase). After approval, refunds usually process within "
                "5–7 business days back to the original payment method. "
                "Some items (like final sale or certain products) may have exceptions. "
                "If you share your order number, I can help check your specific case."
            )

    elif intent == "refund_request":
        if not order_id:
            reply = (
                "I can help with a refund. What’s your order number? "
                "Once I have it, I’ll guide you through the next steps."
            )
        else:
            if not refund_reason:
                reply = (
                    f"Thanks. What’s the reason for the refund for order {order_id}? "
                    "For example: damaged item, wrong item, not as described, missing parts, or late delivery."
                )
            else:
                reply = (
                    f"Got it. Based on your request, here’s what we’ll do for order {order_id}: "
                    f"{refund_reason} "
                    "If your item is eligible, we’ll start the return/refund process and send "
                    "instructions for next steps. After approval, refunds typically process within 5–7 business days. "
                    "Do you want to start a return now, or do you have another question?"
                )

    elif intent == "product_info":
        hit = answer_via_faq(user_message)
        if hit is not None:
            reply = hit.answer
        else:
            reply = (
                "Sure—what product are you asking about (name/model or a link)? "
                "And what specifically do you need: price, specs, compatibility, availability, or warranty?"
            )

    elif intent == "general_query":
        # Prefer FAQ retrieval for broader coverage.
        hit = answer_via_faq(user_message)
        if hit is not None:
            reply = hit.answer
        else:
            reply = "I can help. What topic is your question about—orders, refunds/returns, shipping, or something else?"

    else:
        # Unknown with context already handled above.
        hit = answer_via_faq(user_message)
        if hit is not None:
            reply = hit.answer
        else:
            reply = "I’m not totally sure I understood. Could you rephrase or tell me what you need help with?"

    append_history(state, role="bot", text=reply)
    state["context"]["last_intent"] = intent
    return reply, state

