from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Dict, List, Tuple

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder


# Keep labels aligned with `chatbot.intents`.
INTENTS = [
    "order_status",
    "refund_request",
    "refund_policy",
    "product_info",
    "human_agent",
    "greeting",
    "general_query",
    "unknown",
]


@dataclass
class Prediction:
    intent: str
    confidence: float


def _training_data() -> List[Tuple[str, str]]:
    """
    Small built-in dataset so the project runs without extra files.

    You can expand this list to improve accuracy.
    """
    order_status = [
        "where is my order",
        "order status",
        "track my order",
        "tracking",
        "delivery status",
        "shipped",
        "out for delivery",
        "my package is late",
        "when will it arrive",
        "not arrived yet",
        "it says stuck",
        "update on delivery",
        "where's my delivery",
        "how long until it ships",
    ]

    refund_request = [
        "i want a refund",
        "refund my order",
        "requesting a refund",
        "start a return",
        "start return",
        "return this item",
        "send it back",
        "i need to return",
        "cancel my order and refund",
        "money back please",
        "i want to return",
        "open a return",
        "initiate return",
        "chargeback",
    ]

    refund_policy = [
        "refund policy",
        "return policy",
        "how long do refunds take",
        "how long refunds",
        "when will I get my money back",
        "returns eligibility",
        "refund timeline",
        "processing time",
        "refunds for late deliveries",
        "refund for late delivery",
        "if delivery is late can i get a refund",
        "late delivery refund policy",
        "do you accept returns",
        "what is the return window",
        "are there exceptions",
        "how long can i return",
        "returns",
        "return window",
    ]

    product_info = [
        "what is the warranty",
        "does it have warranty",
        "do you have a warranty",
        "warranty",
        "price",
        "product details",
        "specs",
        "compatibility",
        "compatibility with my device",
        "is it compatible with my device",
        "compatible with my device",
        "does it work with my phone",
        "will it work on my device",
        "availability",
        "does it come with",
        "is it compatible",
        "product availability",
    ]

    human_agent = [
        "talk to a human",
        "human agent",
        "customer service",
        "representative",
        "i need support",
        "connect me to support",
        "support person",
    ]

    greeting = [
        "hi",
        "hello",
        "hey",
        "good morning",
        "good afternoon",
    ]

    general_query = [
        "i have a question",
        "help",
        "what can you do",
        "i need assistance",
        "something else",
        "i am confused",
        "compatibility with my device",
        "warranty",
        "do you offer refunds for late deliveries",
    ]

    built_in = (
        [(t, "order_status") for t in order_status]
        + [(t, "refund_request") for t in refund_request]
        + [(t, "refund_policy") for t in refund_policy]
        + [(t, "product_info") for t in product_info]
        + [(t, "human_agent") for t in human_agent]
        + [(t, "greeting") for t in greeting]
        + [(t, "general_query") for t in general_query]
    )

    # Optional: load extra training examples from `data/intent_training.json`.
    # Expected format:
    # [
    #   {"text": "where is my order", "intent": "order_status"},
    #   {"text": "i want a refund", "intent": "refund_request"}
    # ]
    base_dir = os.path.dirname(os.path.dirname(__file__))
    ext_path = os.path.join(base_dir, "data", "intent_training.json")
    if not os.path.exists(ext_path):
        return built_in

    try:
        with open(ext_path, "r", encoding="utf-8") as f:
            extra = json.load(f)
    except Exception:
        return built_in

    out: List[Tuple[str, str]] = list(built_in)
    if isinstance(extra, list):
        for item in extra:
            if not isinstance(item, dict):
                continue
            text = item.get("text") or item.get("sentence") or item.get("utterance")
            intent = item.get("intent") or item.get("label")
            if not text or not intent:
                continue
            intent_str = str(intent).strip()
            text_str = str(text).strip()
            if intent_str in INTENTS and text_str:
                out.append((text_str, intent_str))
    return out


def _build_pipeline() -> Pipeline:
    tfidf = TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),
        stop_words="english",
        max_features=5000,
    )
    clf = LogisticRegression(max_iter=2000)
    return Pipeline([("tfidf", tfidf), ("clf", clf)])


def train_model() -> Tuple[Pipeline, LabelEncoder]:
    data = _training_data()
    texts = [t for t, _ in data]
    labels = [label for _, label in data]

    le = LabelEncoder()
    y = le.fit_transform(labels)
    pipe = _build_pipeline()
    pipe.fit(texts, y)
    return pipe, le


_CACHED: Tuple[Pipeline, LabelEncoder] | None = None


def predict_intent(message: str, *, threshold: float = 0.45) -> Prediction:
    """
    Predict intent with a confidence threshold.

    Returns `unknown` when confidence is low.
    """
    global _CACHED
    if _CACHED is None:
        _CACHED = train_model()

    pipe, le = _CACHED

    probs = pipe.predict_proba([message])[0]
    best_idx = int(probs.argmax())
    best_label = le.inverse_transform([best_idx])[0]
    confidence = float(probs[best_idx])

    if best_label not in INTENTS:
        best_label = "unknown"

    if confidence < threshold:
        best_label = "unknown"

    return Prediction(intent=best_label, confidence=confidence)

