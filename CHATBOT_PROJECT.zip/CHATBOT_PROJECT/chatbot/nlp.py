from typing import Optional

from .intents import ParsedMessage, parse_user_message


def parse_user_message_for_chat(message: str, last_intent: Optional[str]) -> ParsedMessage:
    """
    NLP entry point for the chat system.
    Currently keyword-based, but kept modular so you can swap in ML later.
    """
    return parse_user_message(message=message, last_intent=last_intent)

