import threading
import time
import uuid
from dataclasses import dataclass

# In-memory conversation store.
# For production, replace with Redis/DB persistence.
_conversations = {}
_lock = threading.Lock()


def _new_conversation_state() -> dict:
    return {
        "conversation_id": None,  # assigned when first created
        "history": [],  # list of {"role": "user"/"bot", "text": ...}
        "context": {
            "last_intent": None,
            "order_id": None,
            "refund_reason": None,
            "waiting_for_order_email": False,
        },
        "last_active": time.time(),
    }


def get_conversation_state(session: dict) -> dict:
    """
    Get or initialize per-user conversation state.

    `session` is Flask's session object; it stores only the conversation_id.
    The full state lives in this module's in-memory dict.
    """
    with _lock:
        conversation_id = session.get("conversation_id")
        if not conversation_id:
            conversation_id = str(uuid.uuid4())
            session["conversation_id"] = conversation_id

        state = _conversations.get(conversation_id)
        if state is None:
            state = _new_conversation_state()
            state["conversation_id"] = conversation_id
            _conversations[conversation_id] = state

        state["last_active"] = time.time()
        return state


def append_history(state: dict, role: str, text: str) -> None:
    with _lock:
        state["history"].append({"role": role, "text": text})
        # Keep last N turns to limit memory growth.
        if len(state["history"]) > 30:
            state["history"] = state["history"][-30:]

