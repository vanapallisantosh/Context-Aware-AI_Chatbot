import os

from flask import Flask, jsonify, render_template, request, session

from chatbot.context import get_conversation_state
from chatbot.intents import DEFAULT_FALLBACK_INTENT
from chatbot.logging_utils import log_interaction
from chatbot.nlp import parse_user_message_for_chat
from chatbot.responses import build_response


def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-secret-key-change-me")

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.post("/chat")
    def chat():
        data = request.get_json(silent=True) or {}
        user_message = (data.get("message") or "").strip()

        if not user_message:
            return jsonify({"reply": "Please type a message."})

        state = get_conversation_state(session)
        last_intent = state["context"].get("last_intent")

        parsed = parse_user_message_for_chat(user_message, last_intent=last_intent)

        reply_text, updated_state = build_response(state=state, user_message=user_message, parsed=parsed)
        # `build_response` may adjust intent using context fallback.
        intent = updated_state["context"].get("last_intent") or parsed.intent or DEFAULT_FALLBACK_INTENT
        # `updated_state` is the same dict object stored in-memory; session only stores conversation_id.

        log_interaction(
            conversation_id=updated_state["conversation_id"],
            user_message=user_message,
            bot_reply=reply_text,
            intent=intent,
        )

        return jsonify(
            {
                "reply": reply_text,
                "intent": intent,
            }
        )

    return app


app = create_app()


if __name__ == "__main__":
    # For local testing.
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=True)

