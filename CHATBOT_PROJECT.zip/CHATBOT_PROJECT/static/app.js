const form = document.getElementById("chatForm");
const input = document.getElementById("messageInput");
const main = document.getElementById("chatMain");
const sendBtn = document.getElementById("sendBtn");

let isSending = false;

function escapeHtml(str) {
  return (str || "").replace(/[&<>"']/g, (m) => {
    const map = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" };
    return map[m] || m;
  });
}

function appendBubble(text, kind) {
  const bubble = document.createElement("div");
  bubble.className = `bubble ${kind}`;
  bubble.textContent = text;
  main.appendChild(bubble);
  main.scrollTop = main.scrollHeight;
  return bubble;
}

function showTyping() {
  const bubble = appendBubble("Thinking...", "bot");
  bubble.classList.add("typing");
  return bubble;
}

async function sendMessage(message) {
  const payload = { message };

  sendBtn.disabled = true;
  input.disabled = true;

  const typing = showTyping();
  const start = Date.now();
  try {
    const res = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    const elapsed = Date.now() - start;
    const minTypingMs = 300;
    const waitMs = Math.max(0, minTypingMs - elapsed);
    if (waitMs > 0) await new Promise((r) => setTimeout(r, waitMs));
    typing.remove();
    appendBubble(data.reply || "Sorry—something went wrong.", "bot");
  } catch (err) {
    typing.remove();
    appendBubble("Sorry—there was an error contacting the server.", "bot");
  } finally {
    sendBtn.disabled = false;
    input.disabled = false;
    input.focus();
    isSending = false;
  }
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  if (isSending || sendBtn.disabled) return;
  const message = input.value.trim();
  if (!message) return;

  // Lock early to avoid duplicate submit events (e.g., Enter timing).
  isSending = true;
  appendBubble(message, "user");
  input.value = "";
  sendMessage(message);
});

// Optional: send on Enter key while still allowing multiline? (input is single-line)
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    // Prevent browser's implicit submit; we route everything through the submit handler.
    e.preventDefault();
    if (!isSending && !sendBtn.disabled) form.requestSubmit();
  }
});

